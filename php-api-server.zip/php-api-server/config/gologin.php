<?php
class GoLoginAPI {
    private $apiToken;
    private $baseUrl = 'https://api.gologin.com';

    public function __construct() {
        $this->apiToken = $_ENV['GOLOGIN_API_TOKEN'] ?? '';
        if (empty($this->apiToken)) {
            throw new Exception("GoLogin API token is required");
        }
    }

    private function makeRequest($endpoint, $method = 'GET', $data = null) {
        $url = $this->baseUrl . $endpoint;
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $this->apiToken,
            'Content-Type: application/json'
        ]);

        switch ($method) {
            case 'POST':
                curl_setopt($ch, CURLOPT_POST, true);
                if ($data) {
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                }
                break;
            case 'PUT':
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
                if ($data) {
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                }
                break;
            case 'DELETE':
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
                break;
        }

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($response === false) {
            throw new Exception("cURL error: " . curl_error($ch));
        }

        $decodedResponse = json_decode($response, true);
        
        if ($httpCode >= 400) {
            throw new Exception("GoLogin API error: " . ($decodedResponse['message'] ?? 'Unknown error'));
        }

        return $decodedResponse;
    }

    public function listProfiles($page = 1, $search = null, $folder = null) {
        $params = ['page' => $page];
        if ($search) $params['search'] = $search;
        if ($folder) $params['folder'] = $folder;
        
        $queryString = http_build_query($params);
        return $this->makeRequest('/browser/v2?' . $queryString);
    }

    public function getProfile($profileId) {
        return $this->makeRequest('/browser/' . $profileId);
    }

    public function createProfile($profileData) {
        return $this->makeRequest('/browser/custom', 'POST', $profileData);
    }

    public function createQuickProfile($os, $name, $osSpec = null) {
        $data = [
            'name' => $name,
            'os' => $os
        ];
        if ($osSpec) {
            $data['osSpec'] = $osSpec;
        }
        return $this->makeRequest('/browser/quick', 'POST', $data);
    }

    public function updateProfile($profileId, $profileData) {
        return $this->makeRequest('/browser/' . $profileId, 'PUT', $profileData);
    }

    public function deleteProfile($profileId) {
        return $this->makeRequest('/browser/' . $profileId, 'DELETE');
    }

    public function setProfileProxy($profileId, $proxy) {
        return $this->makeRequest('/browser/' . $profileId . '/proxy', 'PUT', $proxy);
    }

    public function removeProfileProxy($profileId) {
        return $this->makeRequest('/browser/' . $profileId . '/proxy', 'DELETE');
    }

    public function launchProfile($profileId, $options = []) {
        return $this->makeRequest('/browser/' . $profileId . '/start', 'POST', $options);
    }

    public function stopProfile($profileId) {
        return $this->makeRequest('/browser/' . $profileId . '/stop', 'POST');
    }

    public function listFolders() {
        return $this->makeRequest('/browser/folders');
    }

    public function createFolder($name) {
        return $this->makeRequest('/browser/folders', 'POST', ['name' => $name]);
    }

    public function listTags() {
        return $this->makeRequest('/browser/tags');
    }

    public function getProxyLocations() {
        return $this->makeRequest('/browser/proxy-locations');
    }

    public function testConnection() {
        try {
            $this->makeRequest('/browser/v2?page=1');
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
}
?>
